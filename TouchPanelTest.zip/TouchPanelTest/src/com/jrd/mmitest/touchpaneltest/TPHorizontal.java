package com.jrd.mmitest.touchpaneltest;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class TPHorizontal extends Activity {

	private static String TAG = "TouchPanel";
	private int flagUp = 0;

	private int tolerance = 80;
	private int dist = (Lcd.height() - tolerance * 4) / 5;

	private int minPathLength = Lcd.width() - Lcd.height() / 8;

	private Point[] p1 = { new Point(0, dist), new Point(0, dist + tolerance),
			new Point(Lcd.width(), dist + tolerance),
			new Point(Lcd.width(), dist) };

	private Point[] p2 = { new Point(0, dist * 2 + tolerance),
			new Point(0, dist * 2 + tolerance * 2),
			new Point(Lcd.width(), dist * 2 + tolerance * 2),
			new Point(Lcd.width(), dist * 2 + tolerance) };

	private Point[] p3 = { new Point(0, dist * 3 + tolerance * 2),
			new Point(0, dist * 3 + tolerance * 3),
			new Point(Lcd.width(), dist * 3 + tolerance * 3),
			new Point(Lcd.width(), dist * 3 + tolerance * 2) };

	private Point[] p4 = { new Point(0, dist * 4 + tolerance * 3),
			new Point(0, dist * 4 + tolerance * 4),
			new Point(Lcd.width(), dist * 4 + tolerance * 4),
			new Point(Lcd.width(), dist * 4 + tolerance * 3) };

	final Parallelepipede pl1 = new Parallelepipede(p1);
	final Parallelepipede pl2 = new Parallelepipede(p2);
	final Parallelepipede pl3 = new Parallelepipede(p3);
	final Parallelepipede pl4 = new Parallelepipede(p4);

	float mAverageX = 0;
	float mAverageY = 0;

	int mEcartType = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(new MyView(this));
	}

	public class MyView extends View {

		private Bitmap mBitmap;
		private Canvas mCanvas;
		private Path mPath;
		private Paint mBitmapPaint;
		private Paint mPaint;

		private boolean outFlag = false;

		public MyView(Context context) {
			super(context);

			mPaint = new Paint();
			mPaint.setAntiAlias(true);
			mPaint.setColor(0xFFFF0000);
			mPaint.setStyle(Paint.Style.STROKE);
			mPaint.setStrokeJoin(Paint.Join.BEVEL);
			mPaint.setStrokeCap(Paint.Cap.ROUND);
			mPaint.setStrokeWidth(1);
			mBitmap = Bitmap.createBitmap(Lcd.width(), Lcd.height(),
					Bitmap.Config.ARGB_8888);
			mCanvas = new Canvas(mBitmap);
			mPath = new Path();
			mBitmapPaint = new Paint(Paint.DITHER_FLAG);
		}

		@Override
		protected void onDraw(Canvas canvas) {
			canvas.drawColor(Color.BLACK/* 0xFFAAAAAA */);
			canvas.drawBitmap(mBitmap, 0, 0, mBitmapPaint);

			/* draw parallelepipede on the screen */
			pl1.draw(canvas);
			pl2.draw(canvas);
			pl3.draw(canvas);
			pl4.draw(canvas);

			/* draw references lines on the screen */
			Paint p = new Paint();
			p.setColor(Color.GREEN);
			p.setStyle(Paint.Style.STROKE);
			p.setTextSize(30);

			// header text
			canvas.drawText("Please draw on ", Lcd.width() / 2 - 100, 25, p);
			canvas.drawText("the yellow area", Lcd.width() / 2 - 100, 50, p);
			/* draw the current pen position */
			canvas.drawPath(mPath, mPaint);
		}

		private float mX, mY;
		private static final float TOUCH_TOLERANCE = 1;

		private void touch_start(float x, float y) {
			mPath.reset();
			mPath.moveTo(x, y);
			mX = x;
			mY = y;
		}

		private void touch_move(float x, float y) {
			float dx = Math.abs(x - mX);
			float dy = Math.abs(y - mY);
			if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
				mPath.quadTo(mX, mY, (x + mX) / 2, (y + mY) / 2);
				mX = x;
				mY = y;
			}
		}

		private void touch_up() {
			mPath.lineTo(mX, mY);
			mCanvas.drawPath(mPath, mPaint);
			flagUp++;
		}

		@Override
		public boolean onTouchEvent(MotionEvent event) {
			float x = event.getX();
			float y = event.getY();

			// check if the point is inside the bounds drawn on the screen
			if (!pl1.includePoint(x, y) && !pl2.includePoint(x, y)
					&& !pl3.includePoint(x, y) && !pl4.includePoint(x, y)) {
				outFlag = true;
			}

			Log.d(TAG, "x = " + x + " y = " + y);

			switch (event.getAction()) {
			case MotionEvent.ACTION_DOWN:
				touch_start(x, y);
				invalidate();
				mAverageX = x;
				mAverageY = y;
				break;
			case MotionEvent.ACTION_MOVE:
				touch_move(x, y);
				invalidate();
				mAverageX = (x + mAverageX) / 2;
				mAverageY = (y + mAverageY) / 2;
				break;
			case MotionEvent.ACTION_UP:
				touch_up();
				invalidate();
				if (outFlag) {
					TestResult.OUT_OF_BOUNDS++;
					outFlag = false;
				}
				Log.d(TAG, "AVERAGES : x = " + mAverageX + " y = " + mAverageY);
				/* check the length of the path */
				RectF rect = new RectF(0, 0, 0, 0);
				mPath.computeBounds(rect, true);
				float mPathLength = (float) Math.sqrt(rect.height()
						* rect.height() + rect.width() * rect.width());
				Log.i(TAG, "path length is " + mPathLength);

				if (mPathLength < minPathLength) {
					TestResult.LINE_SHORT++;
				} else {
					if (pl1.includePoint(x, y)) {
						pl1.setFinish(true);
					}
					if (pl2.includePoint(x, y)) {
						pl2.setFinish(true);
					}
					if (pl3.includePoint(x, y)) {
						pl3.setFinish(true);
					}
					if (pl4.includePoint(x, y)) {
						pl4.setFinish(true);
					}
					// if (pl1.getFinish() && pl2.getFinish() && pl3.getFinish()
					// && pl4.getFinish()) {
					// startActivity(new Intent(TPHorizontal.this,
					// TPVertical.class));
					// finish();
					// }
				}
				if (flagUp == 4) {
					startActivity(new Intent(TPHorizontal.this,
							TPVertical.class));
					flagUp = 0;
					finish();
				}
				break;
			}
			return true;
		}
	}

	class Parallelepipede {
		private Path mPath;
		private Paint mPaint;
		private Point[] points;
		private boolean isFinished;

		Parallelepipede(Point[] p) {
			points = p.clone();
			mPath = new Path();

			mPaint = new Paint();
			mPaint.setAntiAlias(true);
			mPaint.setColor(Color.YELLOW);
			mPaint.setStyle(Paint.Style.FILL);
			mPaint.setStrokeJoin(Paint.Join.BEVEL);
			mPaint.setStrokeCap(Paint.Cap.ROUND);
			mPaint.setStrokeWidth(1);
		}

		void draw(Canvas c) {
			mPath.reset();
			mPath.moveTo(points[0].x, points[0].y);
			for (int i = 1; i < points.length; i++) {
				mPath.lineTo(points[i].x, points[i].y);
			}
			mPath.close();
			c.drawPath(mPath, mPaint);
		}

		void setFinish(boolean b) {
			isFinished = b;
		}

		boolean getFinish() {
			return isFinished;
		}

		/*
		 * checks if the point (x,y) is included in the Parallelepipede
		 */

		public boolean includePoint(float x, float y) {
			Point p = new Point((int) x, (int) y);
			double d1 = distLineToPoint(points[0], points[3], p);
			double d2 = distLineToPoint(points[2], points[1], p);
			double range = distLineToPoint(points[0], points[3], points[2]);
			Log.d("TouchPanel", "includePoint: " + d1 + " " + d2 + " " + range);
			/*
			 * to be included in the shape, the distance from (x,y) to the
			 * bottom or top line should not exceed the distance between the
			 * bottom to top line
			 */
			if (Math.max(d1, d2) < range) {
				return true;
			}
			return false;
		}

		/* computes the shortest distance form a point to a line */
		/*                                                       
		 * 
		 */
		private double distLineToPoint(Point A, Point B, Point p) {

			/*
			 * let [AB] be the segment and C the projection of C on (AB) AC * AB
			 * (Cx-Ax)(Bx-Ax) + (Cy-Ay)(By-Ay) u = ------- =
			 * ------------------------------- ||AB||^2 ||AB||^2
			 */
			double det = Math.pow(B.x - A.x, 2) + Math.pow(B.y - A.y, 2);
			if (det == 0) {
				return 0;
			}

			double u = ((p.x - A.x) * (B.x - A.x) + (p.y - A.y) * (B.y - A.y))
					/ det;

			/*
			 * The projection point P can then be found:
			 * 
			 * Px = Ax + r(Bx-Ax) Py = Ay + r(By-Ay)
			 */
			double Px = A.x + u * (B.x - A.x);
			double Py = A.y + u * (B.y - A.y);

			double distance = Math.sqrt(Math.pow(Px - p.x, 2)
					+ Math.pow(Py - p.y, 2));

			return distance;
		}

	}

}
