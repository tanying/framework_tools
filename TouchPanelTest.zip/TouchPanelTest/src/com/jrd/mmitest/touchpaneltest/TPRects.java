package com.jrd.mmitest.touchpaneltest;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.GridLayout.LayoutParams;
import android.widget.LinearLayout;

public class TPRects extends Activity {

	private GridLayout glRects;
	private LinearLayout llRects;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tp_rect);
		initViews();
	}

	private void initViews() {
		glRects = (GridLayout) findViewById(R.id.gl_rect);
		glRects.setColumnCount(4);
		glRects.setRowCount(5);
		int itemWidth = Lcd.width() / 4;

		LayoutParams params = null;

		for (int i = 0; i < 20; i++) {
			params = new LayoutParams();
			params.width = itemWidth;
			params.height = itemWidth;
			glRects.addView(new RectItem(this), params);
		}

		llRects = (LinearLayout) findViewById(R.id.ll_rect);

		for (int i = 0; i < 4; i++) {
			params = new LayoutParams();
			params.width = (int) (itemWidth * 0.8);
			params.height = (int) (itemWidth * 0.8);
			llRects.addView(new RectItem(this), params);
		}

		Button btnFinish = new Button(this);
		params = new LayoutParams();
		params.width = (int) (itemWidth * 0.8);
		params.height = (int) (itemWidth * 0.8);
		llRects.addView(btnFinish, params);
		btnFinish.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startActivity(new Intent(TPRects.this, Results.class));
				finish();
			}
		});
	}

	public class RectItem extends FrameLayout implements OnClickListener,
			OnLongClickListener {

		private Button button;
		private boolean isClick = false, isLongClick = false;

		public RectItem(Context context) {
			super(context);
			button = new Button(context);
			LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT,
					LayoutParams.MATCH_PARENT);
			params.setMargins(10, 10, 10, 10);
			button.setGravity(Gravity.CENTER);
			button.setBackgroundColor(Color.YELLOW);
			button.setOnClickListener(this);
			button.setOnLongClickListener(this);
			addView(button, params);
		}

		@Override
		public void onClick(View v) {
			if (!isClick) {
				button.setBackgroundColor(Color.GREEN);
				TestResult.RECT_MISSED--;
			}
			isClick = true;
		}

		@Override
		public boolean onLongClick(View v) {
			if (!isLongClick) {
				button.setBackgroundColor(Color.RED);
				TestResult.RECT_LONG_PRESSED++;
			}
			isLongClick = true;
			return true;
		}
	}
}
