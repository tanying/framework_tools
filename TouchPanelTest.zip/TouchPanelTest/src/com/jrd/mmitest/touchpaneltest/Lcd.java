package com.jrd.mmitest.touchpaneltest;

class Lcd {
	private Lcd() {
		Width = 480;
		Height = 800;
	}

	private int Width, Height;

	static private Lcd _instance = new Lcd();

	static public void setSize(int w, int h) {
		_instance.Width = w;
		_instance.Height = h;
	}

	static public int width() {
		return _instance.Width;
	}

	static public int height() {
		return _instance.Height;
	}
}