package com.jrd.mmitest.touchpaneltest;

public class TestResult {

	public static int OUT_OF_BOUNDS = 0;
	public static int LINE_SHORT = 0;
	public static int RECT_MISSED = 24;
	public static int RECT_LONG_PRESSED = 0;
}
