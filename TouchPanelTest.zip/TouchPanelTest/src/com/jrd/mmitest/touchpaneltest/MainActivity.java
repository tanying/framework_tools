package com.jrd.mmitest.touchpaneltest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {

	public DisplayMetrics metrics = new DisplayMetrics();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		int mask = WindowManager.LayoutParams.FLAG_FULLSCREEN;
		mask |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
		getWindow().setFlags(mask, mask);

		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		Lcd.setSize(getWindowManager().getDefaultDisplay().getWidth(),
				getWindowManager().getDefaultDisplay().getHeight());
		
		setContentView(R.layout.main);
	}

	public void Start(View view) {
		startActivity(new Intent(this, TPHorizontal.class));
	}
}
