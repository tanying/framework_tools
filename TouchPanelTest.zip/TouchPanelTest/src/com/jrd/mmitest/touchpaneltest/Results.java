package com.jrd.mmitest.touchpaneltest;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Results extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tp_result);
		TextView textView = (TextView) findViewById(R.id.tv_title);
		boolean flag = TestResult.LINE_SHORT == 0 ? true : false;
		flag = flag && TestResult.OUT_OF_BOUNDS == 0 ? true : false;
		flag = flag && TestResult.RECT_MISSED == 0 ? true : false;
		String result = "";
		if (flag) {
			result = "Success";
		} else {
			result = "Fail";
		}
		textView.setText("Result: " + result + "\n" + "Failure count" + "\n"
				+ "Line out of bounds:" + TestResult.OUT_OF_BOUNDS + "\n"
				+ "Line is too short:" + TestResult.LINE_SHORT + "\n"
				+ "Missed Icon:"
				+ (TestResult.RECT_MISSED - TestResult.RECT_LONG_PRESSED)
				+ "\n" + "Long Press:" + TestResult.RECT_LONG_PRESSED);
	}

	public void exit(View view) {
		TestResult.LINE_SHORT = 0;
		TestResult.OUT_OF_BOUNDS = 0;
		TestResult.RECT_LONG_PRESSED = 0;
		TestResult.RECT_MISSED = 24;
		finish();
	}
}
