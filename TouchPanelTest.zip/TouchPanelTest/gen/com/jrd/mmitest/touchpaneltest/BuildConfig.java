/** Automatically generated file. DO NOT MODIFY */
package com.jrd.mmitest.touchpaneltest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}